

<!DOCTYPE html>
<html>
<head>
    <link href="Styles.css" rel="stylesheet" type="text/css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bungee+Spice&display=swap" rel="stylesheet">
</head>
<body>
<table>
<?php

//Do SELECT on database

// Connect to MySQL, select database
$con = mysqli_connect ( "webdev.bentley.edu", "jcooper", "5047", "jcooper" );

// Check connection
if (mysqli_connect_errno (  ))
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error ()."<br>";
    exit("Connect Error");
}
//else echo 'Connected successfully' . '<br>';

// Perform SQL query
$query = "SELECT * FROM person;";
$result = mysqli_query($con, $query) or  die('Query failed: ' . mysqli_errno($con));


// loop over result set. Print field values for each record
while ($line = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    // start table row
    echo "<tr>";

    // inner loop. Print each field value for a record
    foreach ($line as $field_value) {
        echo "<td>", "$field_value", "</td>";
    }
    // end table row and loop
    echo "</tr>";
}

// close connection
mysqli_close($con);


// close connection
mysqli_close ($con);

?>
