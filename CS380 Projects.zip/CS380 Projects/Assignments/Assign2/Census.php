<?php
//1. How many names are common to both boys and girls?
/*
$boyFile = fopen("boynames.txt", "r");
$boyNames = array();
$girlNames = array();
$allNames = array();
$commonNames = array();

while (!feof($boyFile))
{
    $line = fgets($boyFile);
    $entries = explode(" ", $line);
    $boyNames[] = $entries[0];
}

fclose($boyFile);

//echo '<pre>'; print_r($allNames); echo '</pre>';

$girlFile = fopen("girlnames.txt", "r");

while (!feof($girlFile))
{
    $line = fgets($girlFile);
    $entries = explode(" ", $line);
    $girlNames = $entries[0];
}

fclose($girlFile);

for ($i =0; $i<sizeof($girlNames); $i++)
{
    $searched = array_search($girlNames[$i], $boyNames);
    var_dump($girlNames[$i]);
    if ($searched === false)
    {
        echo $girlNames[$i] . " is not a match" . "<br>";
    }
    else
    {
        echo $girlNames[$i] . " is a match" . "<br>";
    }
}*/



//echo '<pre>'; print_r($allNames); echo '</pre>';
//echo '<pre>'; print_r($commonNames); echo '</pre>';



$boyNames = array();

$stream = fopen("boynames.txt", "r");

while( !feof($stream))
{
    $word = fgets($stream);
    $entries = explode(" ", $word);
    $boyNames[] = $entries[0];   //put word in array
    //$boyNames[] = $entries[0] . " " . "<br>";
}

fclose($stream);


$stream = fopen("girlnames.txt", "r");

while( !feof($stream))
{
     $word = fgets($stream);
     $entries = explode(" ", $word);
     $girlNames[] = $entries[0];   //put word in array

}

for($i=0; $i<sizeof($girlNames); $i++){
    echo $girlNames[$i]."<br>";
}


//$line = "Jacob the purple dragon is walking on the roof";
//print_r($tokens = explode(" ", $line));
/*

for ($i = 0; $i<sizeof($girlNames); $i++)
{
    $searched = array_search($girlNames[$i], $boyNames);
    //  var_dump($tokens[$i]);
    if ($searched === true)
    {
        echo $girlNames[$i] . " is a match" . "<br>";
    }
     else
    {
        echo $girlNames[$i] . " is not a match" . "<br>";
    }
}

*/









//2. List the common names with how many boys and how many girls have that name.
//    Use a single HTML table to display this data.


//3. How many total boys and how many total girls were born last year according to the census?

?>