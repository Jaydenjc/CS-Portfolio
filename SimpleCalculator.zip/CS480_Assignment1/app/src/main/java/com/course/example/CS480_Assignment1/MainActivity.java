package com.course.example.CS480_Assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button go;
    private TextView tipCalc, checkAmountT, numOfPeopleT, tipPercentT, totalBillT, totalPerPersonT,
                    totalTipT, tipPerPersonT, totalBillE, totalPerPersonE, totalTipE, tipPerPersonE;
    private EditText checkAmountE, numOfPeopleE, tipPercentE;

    private double check = 0, num = 0, tipP = 0, bill = 0, tipV = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get references to widgets
        tipCalc = (TextView)findViewById(R.id.tipCalcT);
        checkAmountT = (TextView)findViewById(R.id.caT);
        checkAmountE = (EditText)findViewById(R.id.caE);
        numOfPeopleT = (TextView)findViewById(R.id.nopT);
        numOfPeopleE = (EditText)findViewById(R.id.nopE);
        tipPercentT = (TextView)findViewById(R.id.tpT);
        tipPercentE = (EditText)findViewById(R.id.tpE);
        go = (Button)findViewById(R.id.goB);
        totalBillT = (TextView)findViewById(R.id.tbT);
        totalBillE = (TextView)findViewById(R.id.tbE);
        totalPerPersonT = (TextView)findViewById(R.id.tppT);
        totalPerPersonE = (TextView)findViewById(R.id.tppE);
        totalTipT = (TextView)findViewById(R.id.ttT);
        totalTipE = (TextView)findViewById(R.id.ttE);
        tipPerPersonT = (TextView)findViewById(R.id.tipppT);
        tipPerPersonE = (TextView)findViewById(R.id.tipppE);


        //set listener of go button
        go.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
               /* double oper = Double.parseDouble(operand.getText().toString());
                double res = Double.parseDouble(result.getText().toString());
                double sum = res + oper;
                operand.setText("");
                result.setText(new Double(sum).toString()); */

                double check = Double.parseDouble(checkAmountE.getText().toString());
                double num = Double.parseDouble(numOfPeopleE.getText().toString());
                double tipP = Double.parseDouble(tipPercentE.getText().toString());
                double bill = Double.parseDouble(totalBillE.getText().toString());
                double tipV = Double.parseDouble(totalTipE.getText().toString());

                double tipValue = check * (1 - (tipP / 100));
                totalTipE.setText(new Double(tipValue).toString());
                double billValue = check + tipValue;
                totalBillE.setText(new Double(billValue).toString());
                double totalppValue = billValue / num;
                totalPerPersonE.setText(new Double(totalppValue).toString());
                double tipppValue = tipValue / num;
                tipPerPersonE.setText(new Double(tipppValue).toString());
            }
        });

    }




}